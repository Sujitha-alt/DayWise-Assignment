package CaseStudy;

import java.time.LocalDate;
import java.time.Period;

public class BookingExample {
    public static void main(String[] args) {
    	
        LocalDate checkInDate = LocalDate.of(2025, 7, 25);
        LocalDate checkOutDate = LocalDate.of(2025, 7, 30);

        System.out.println("Check-in: " + checkInDate);
        System.out.println("Check-out: " + checkOutDate);

        Period duration = Period.between(checkInDate, checkOutDate);
        System.out.println("Duration: " + duration.getDays() + " days");

        if (checkOutDate.isAfter(checkInDate)) {
            System.out.println("Booking confirmed!");
        } else {
            System.out.println("Error: Check-out must be after check-in.");
        }

        LocalDate today = LocalDate.now();
        System.out.println("Today's date: " + today);

        if (checkInDate.isBefore(today)) {
            System.out.println("Warning: Check-in date is in the past.");
        }
    }
}