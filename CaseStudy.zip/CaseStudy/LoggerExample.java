package CaseStudy;

@FunctionalInterface
interface LogFilter {
    boolean shouldLog(String message);
}

public class LoggerExample {
    
    public static void log(String message, LogFilter filter) {
        if (filter.shouldLog(message)) {
            System.out.println("LOG: " + message);
        }
    }

    public static void main(String[] args) {
        
        LogFilter errorFilter = msg -> msg.contains("ERROR");

        log("INFO: All systems operational", errorFilter);  
        log("ERROR: Null pointer exception", errorFilter);  
        log("DEBUG: Memory usage at 80%", errorFilter);     

        LogFilter allFilter = msg -> true;
        log("WARN: Disk space low", allFilter);           
    }
}