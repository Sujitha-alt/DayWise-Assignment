package CaseStudy;
import java.util.function.Consumer;

class NotificationService {
    public void sendEmail(String message) {
        System.out.println("Email sent: " + message);
    }

    public void sendSms(String message) {
        System.out.println("SMS sent: " + message);
    }

    public void sendPush(String message) {
        System.out.println("Push Notification sent: " + message);
    }
}

public class NotificationExample {
    public static void main(String[] args) {
        NotificationService service = new NotificationService();

        Consumer<String> emailNotifier = service::sendEmail;
        Consumer<String> smsNotifier = service::sendSms;
        Consumer<String> pushNotifier = service::sendPush;

        emailNotifier.accept("Your invoice is ready.");
        smsNotifier.accept("Your OTP is 123456.");
        pushNotifier.accept("New offer available!");
    }
}