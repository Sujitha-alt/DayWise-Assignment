package CaseStudy;

interface PaymentGateway {
    void pay(double amount);  

    default void logTransaction(double amount) {
        System.out.println("Transaction of ₹" + amount + " is being processed...");
    }
}

class PayPalPayment implements PaymentGateway {
    @Override
    public void pay(double amount) {
        logTransaction(amount); 
        System.out.println("Paid ₹" + amount + " using PayPal.");
    }
}


class UpiPayment implements PaymentGateway {
    @Override
    public void pay(double amount) {
        logTransaction(amount);
        System.out.println("Paid ₹" + amount + " using UPI.");
    }
}

class CardPayment implements PaymentGateway {
    @Override
    public void pay(double amount) {
        logTransaction(amount);
        System.out.println("Paid ₹" + amount + " using Debit/Credit Card.");
    }
}

public class PaymentGatewayExample {
    public static void main(String[] args) {
        PaymentGateway paypal = new PayPalPayment();
        PaymentGateway upi = new UpiPayment();
        PaymentGateway card = new CardPayment();

        paypal.pay(500);
        upi.pay(1200);
        card.pay(750);
    }
}