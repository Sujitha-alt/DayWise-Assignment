package CaseStudy;
import java.util.Arrays;
import java.util.List;


class Employee {
    private String name;
    private double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public String getName() { return name; }
    public double getSalary() { return salary; }

    @Override
    public String toString() {
        return name + " - " + salary;
    }
}

public class LambdaExample {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee("Alice", 50000),
            new Employee("Bob", 70000),
            new Employee("Charlie", 60000)
        );

        employees.sort((e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary()));
        System.out.println("Sorted by salary:");
        employees.forEach(System.out::println);

        System.out.println("\nFiltered by salary > 60000:");
        employees.stream()
                 .filter(e -> e.getSalary() > 60000)
                 .forEach(System.out::println);
    }
}