package CaseStudy;

import java.util.Optional;

class User {
    private String name;
    private Optional<String> phoneNumber;
    private Optional<String> address;

    public User(String name, Optional<String> phoneNumber, Optional<String> address) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public Optional<String> getPhoneNumber() {
        return phoneNumber;
    }

    public Optional<String> getAddress() {
        return address;
    }
}

public class OptionalExample {
    public static void main(String[] args) {
        User user1 = new User("Sujitha", Optional.of("9392762726"), Optional.of("Madanapalle"));
        User user2 = new User("Supriya", Optional.empty(), Optional.of("Angallu"));
        User user3 = new User("Naveen", Optional.empty(), Optional.empty());

        displayUserInfo(user1);
        displayUserInfo(user2);
        displayUserInfo(user3);
    }

    public static void displayUserInfo(User user) {
        System.out.println("Name: " + user.getName());
        System.out.println("Phone: " + user.getPhoneNumber().orElse("Not Provided"));
        System.out.println("Address: " + user.getAddress().orElse("Not Provided"));
        System.out.println("-----");
    }
}