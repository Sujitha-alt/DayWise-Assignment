package CaseStudy;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Order {
    private String customer;
    private double amount;
    private String productCategory;

    public Order(String customer, double amount, String productCategory) {
        this.customer = customer;
        this.amount = amount;
        this.productCategory = productCategory;
    }

    public String getCustomer() { return customer; }
    public double getAmount() { return amount; }
    public String getProductCategory() { return productCategory; }

    @Override
    public String toString() {
        return customer + " - ₹" + amount + " - " + productCategory;
    }
}

public class StreamAPIExample {
    public static void main(String[] args) {
        List<Order> orders = Arrays.asList(
            new Order("Alice", 1200, "Electronics"),
            new Order("Bob", 900, "Books"),
            new Order("Alice", 500, "Books"),
            new Order("Charlie", 1500, "Electronics"),
            new Order("Bob", 2000, "Furniture")
        );

      
        System.out.println("Orders > ₹1000:");
        orders.stream()
              .filter(o -> o.getAmount() > 1000)
              .forEach(System.out::println);

        System.out.println("\nTotal orders per customer:");
        Map<String, Long> orderCount = orders.stream()
            .collect(Collectors.groupingBy(Order::getCustomer, Collectors.counting()));
        orderCount.forEach((customer, count) ->
            System.out.println(customer + ": " + count + " orders")
        );


        System.out.println("\nOrders grouped by product category:");
        Map<String, List<Order>> groupedOrders = orders.stream()
            .collect(Collectors.groupingBy(Order::getProductCategory));
        groupedOrders.forEach((category, orderList) -> {
            System.out.println(category + ":");
            orderList.forEach(System.out::println);
        });
    }
}