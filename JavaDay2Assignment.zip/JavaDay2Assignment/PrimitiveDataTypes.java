package JavaDay2Assignment;

public class PrimitiveDataTypes {

	public static void main(String[] args) {
		int age = 25;
		float height = 5.9f;
		double weight = 68.5;

        System.out.println("Age: " + age);
        System.out.println("Height: " + height);
        System.out.println("Weight: " + weight);

	}

}
