package JavaDay2Assignment;

public class EvenNumbers {

	public static void main(String[] args) {
		int N = 5;
        int count = 0, num = 0;

        while (count < N) {
            System.out.print(num + " ");
            num += 2;
            count++;
        }
    }
}
