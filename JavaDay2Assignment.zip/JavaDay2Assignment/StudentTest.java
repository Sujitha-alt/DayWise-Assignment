package JavaDay2Assignment;

	class Student {
	    String name;
	    int marks;

	    Student(String name, int marks) {
	        this.name = name;
	        this.marks = marks;
	    }

	    void display() {
	        System.out.println("Student Name: " + name);
	        System.out.println("Marks: " + marks);
	    }
	}

	public class StudentTest {
	    public static void main(String[] args) {
	        Student s = new Student("Apsa", 78);
	        s.display();
	    }
	}