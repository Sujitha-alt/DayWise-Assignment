package JavaDay2Assignment;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class NumericFormatting {
    public static void main(String[] args) {
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        System.out.println("Current Date: " + currentDate.format(formatter));

        double amount = 12345.678;
        NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        System.out.println("Formatted Amount: " + nf.format(amount));
    }
}


