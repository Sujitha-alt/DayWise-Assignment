package JavaDay2Assignment;

public class Variables {

	public static void main(String[] args) {
		int id = 101;
        String name = "Ramesh";
        double marks = 87.5;
        char grade = 'A';

        System.out.println("Student ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Marks: " + marks);
        System.out.println("Grade: " + grade);

	}

}
