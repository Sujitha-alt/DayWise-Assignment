package JavaDay2Assignment;

public class EnumExample {
	enum Day {
	    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
	}
	    public static void main(String[] args) {
	        Day today = Day.FRIDAY;

	        switch (today) {
	            case MONDAY:
	                System.out.println("Start of the work week!");
	                break;
	            case FRIDAY:
	                System.out.println("Last working day!");
	                break;
	            case SUNDAY:
	                System.out.println("Relax, it's Sunday!");
	                break;
	            default:
	                System.out.println("Just another weekday.");
	        }
	    }
	}

