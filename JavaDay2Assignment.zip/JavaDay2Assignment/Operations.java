package JavaDay2Assignment;

public class Operations {
	public static void main(String[] args) {
        int number1 = 10, number2 = 20;
        
        System.out.println("Addition: " + (number1 + number2));
        System.out.println("Greater number: " + Math.max(number1, number2));
        System.out.println("Are both positive? " + (number1 > 0 && number2 > 0));

}
}
