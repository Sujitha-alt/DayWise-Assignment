package JavaDay2Assignment;

public class StringBuilderExample {
	    public static void main(String[] args) {
	        String input = "Hello Java Learners";

	        StringBuilder sb = new StringBuilder(input);
	        System.out.println("Original: " + input);
	        System.out.println("Reversed: " + sb.reverse());

}
}
