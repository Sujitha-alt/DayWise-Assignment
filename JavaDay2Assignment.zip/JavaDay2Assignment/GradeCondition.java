package JavaDay2Assignment;

public class GradeCondition {

	public static void main(String[] args) {
		int marks = 56;

        if (marks >= 90)
            System.out.println("Grade: A");
        else if (marks >= 75)
            System.out.println("Grade: B");
        else if (marks >= 60)
            System.out.println("Grade: C");
        else
            System.out.println("Grade: D");
    }
}