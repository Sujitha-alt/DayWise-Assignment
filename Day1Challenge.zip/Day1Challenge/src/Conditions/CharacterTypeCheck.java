package Conditions;

public class CharacterTypeCheck {
    public static void main(String[] args) {
        char ch = 'a'; // Try other characters

        if (Character.isDigit(ch)) {
            System.out.println(ch + " is a digit.");
        } else if (Character.isLetter(ch)) {
            if ("AEIOUaeiou".indexOf(ch) != -1) {
                System.out.println(ch + " is a vowel.");
            } else {
                System.out.println(ch + " is a consonant.");
            }
        } else {
            System.out.println(ch + " is a special character.");
        }
    }
}