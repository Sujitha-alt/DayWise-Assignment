package Conditions;

public class TriangeValidation {
    public static void main(String[] args) {
        int angle1 = 60, angle2 = 60, angle3 = 60;

        if (angle1 + angle2 + angle3 == 180) {
            System.out.println("It is a valid triangle.");
        } else {
            System.out.println("Not a valid triangle.");
        }
    }
}