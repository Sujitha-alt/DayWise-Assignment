package Conditions;

public class EvenAndDivisibleBy5 {
    public static void main(String[] args) {
        int number = 20; // You can change this

        if (number % 2 == 0 && number % 5 == 0) {
            System.out.println(number + " is even and divisible by 5.");
        } else {
            System.out.println(number + " is not both even and divisible by 5.");
        }
    }
}