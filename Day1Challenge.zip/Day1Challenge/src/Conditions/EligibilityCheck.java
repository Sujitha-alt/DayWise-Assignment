package Conditions;

public class EligibilityCheck {
    public static void main(String[] args) {
        int age = 20;

        if (age >= 18) {
            System.out.println("Eligible to vote.");
            if (age >= 18) System.out.println("Eligible to drive.");
            if (age >= 21) System.out.println("Eligible for job.");
            else System.out.println("Not eligible for job yet.");
        } else {
            System.out.println("Not eligible for vote, drive or job.");
        }
    }
}