package StringConcatenation;

public class ConcatenateName {
    public static void main(String[] args) {
        String firstName = "Sujitha";
        String lastName = "Royal";
        String fullName = firstName + " " + lastName;

        System.out.println("Full Name: " + fullName);
    }
}