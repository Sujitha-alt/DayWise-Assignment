package StringConcatenation;

public class PatternBuild {
    public static void main(String[] args) {
        String result = "";
        for (int i = 1; i <= 5; i++) {
            result += i + " ";
        }
        System.out.println("Pattern: " + result);
    }
}