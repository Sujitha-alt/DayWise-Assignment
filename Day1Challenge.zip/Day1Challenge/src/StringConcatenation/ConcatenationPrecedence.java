package StringConcatenation;

public class ConcatenationPrecedence {
    public static void main(String[] args) {
        int a = 5, b = 10;

        System.out.println("Without parentheses: " + a + b);        // 510
        System.out.println("With parentheses: " + (a + b));         // 15
    }
}
