package StringConcatenation;

public class PersonalInfo {
    public static void main(String[] args) {
        String name = "Sujitha";
        int age = 22;
        String address = "Hyderabad";

        String result = "Name: " + name + ", Age: " + age + ", Address: " + address;
        System.out.println(result);
    }
}