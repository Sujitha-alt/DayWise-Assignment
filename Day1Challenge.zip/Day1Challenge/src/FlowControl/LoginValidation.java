package FlowControl;

import java.util.Scanner;

public class LoginValidation {
    public static void main(String[] args) {
        String correctUsername = "Sujitha";
        String correctPassword = "Suji@27";

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        if (username.equals(correctUsername) && password.equals(correctPassword)) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Invalid username or password.");
        }

        sc.close();
    }
}