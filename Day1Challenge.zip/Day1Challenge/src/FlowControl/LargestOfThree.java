package FlowControl;

public class LargestOfThree {
    public static void main(String[] args) {
        int a = 10, b = 25, c = 15;

        if (a > b) {
            if (a > c) {
                System.out.println("a is the largest: " + a);
            } else {
                System.out.println("c is the largest: " + c);
            }
        } else {
            if (b > c) {
                System.out.println("b is the largest: " + b);
            } else {
                System.out.println("c is the largest: " + c);
            }
        }
    }
}