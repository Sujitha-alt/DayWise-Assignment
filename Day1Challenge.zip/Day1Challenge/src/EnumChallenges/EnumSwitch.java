package EnumChallenges;

public class EnumSwitch {
    enum Day {
        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
    }

    public static void main(String[] args) {
        Day today = Day.WEDNESDAY;

        switch (today) {
            case MONDAY -> System.out.println("Start of the week!");
            case FRIDAY -> System.out.println("Almost weekend!");
            case SUNDAY -> System.out.println("Relaxing day!");
            default -> System.out.println("Midweek day");
        }
    }
}