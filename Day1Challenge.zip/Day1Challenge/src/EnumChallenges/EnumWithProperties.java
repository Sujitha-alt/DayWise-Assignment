package EnumChallenges;

public class EnumWithProperties {
    enum Planet {
        EARTH(5.97), MARS(0.642), JUPITER(1898);

        private double mass;

        Planet(double mass) {
            this.mass = mass;
        }

        public double getMass() {
            return mass;
        }
    }

    public static void main(String[] args) {
        System.out.println("Mass of Earth: " + Planet.EARTH.getMass() + " x10^24 kg");
    }
}