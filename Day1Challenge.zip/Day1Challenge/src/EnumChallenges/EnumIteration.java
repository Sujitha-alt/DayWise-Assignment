package EnumChallenges;

public class EnumIteration {
    enum Color {
        RED, GREEN, BLUE
    }

    public static void main(String[] args) {
        for (Color c : Color.values()) {
            System.out.println(c);
        }
    }
}