package EnumChallenges;

public class TrafficLightDemo {
    enum TrafficLight {
        RED("Stop"), GREEN("Go"), YELLOW("Slow Down");

        private String action;

        TrafficLight(String action) {
            this.action = action;
        }

        public String getAction() {
            return action;
        }
    }

    public static void main(String[] args) {
        for (TrafficLight light : TrafficLight.values()) {
            System.out.println(light + ": " + light.getAction());
        }
    }
}