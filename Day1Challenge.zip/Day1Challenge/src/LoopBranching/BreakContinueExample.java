package LoopBranching;

public class BreakContinueExample {
    public static void main(String[] args) {
        System.out.println("Using continue (skip 5):");
        for (int i = 1; i <= 10; i++) {
            if (i == 5) continue;
            System.out.print(i + " ");
        }

        System.out.println("\nUsing break (stop at 5):");
        for (int i = 1; i <= 10; i++) {
            if (i == 5) break;
            System.out.print(i + " ");
        }
    }
}