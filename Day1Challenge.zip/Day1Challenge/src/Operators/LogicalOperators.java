package Operators;

public class LogicalOperators {
    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;

        System.out.println("AND (a && b): " + (a && b));
        System.out.println("OR (a || b): " + (a || b));
        System.out.println("NOT (!a): " + (!a));
    }
}