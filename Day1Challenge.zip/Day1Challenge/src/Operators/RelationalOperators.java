package Operators;

public class RelationalOperators {
    public static void main(String[] args) {
        int age1 = 25, age2 = 30;

        System.out.println("age1 > age2: " + (age1 > age2));
        System.out.println("age1 < age2: " + (age1 < age2));
        System.out.println("age1 == age2: " + (age1 == age2));
        System.out.println("age1 != age2: " + (age1 != age2));
    }
}