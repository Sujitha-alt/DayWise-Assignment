package StringBuilder;

public class StringBuilderDelete {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("RemoveMeNow!");
        sb.delete(6, 8); // Deletes "Me"

        System.out.println("After delete: " + sb.toString()); // Output: RemoveNow!
    }
}