package StringBuilder;

public class StringBuilderReverse {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Hello Java");
        sb.reverse();

        System.out.println("Reversed: " + sb.toString()); // Output: avaJ olleH
    }
}