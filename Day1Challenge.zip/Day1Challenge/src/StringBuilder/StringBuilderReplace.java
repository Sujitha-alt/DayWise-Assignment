package StringBuilder;

public class StringBuilderReplace {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Java is fun");
        sb.replace(8, 11, "awesome"); 

        System.out.println(sb.toString()); 
    }
}