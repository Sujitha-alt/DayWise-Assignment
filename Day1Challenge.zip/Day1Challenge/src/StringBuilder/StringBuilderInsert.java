package StringBuilder;

public class StringBuilderInsert {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Java Programming");
        sb.insert(5, "Language "); 

        System.out.println(sb.toString()); 
    }
}
