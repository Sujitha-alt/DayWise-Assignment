package StringBuilder;

public class StringBuilderAppend {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder();

        sb.append("Hello ");
        sb.append("World!");
        sb.append(" Welcome to Java.");

        System.out.println(sb.toString());
    }
}