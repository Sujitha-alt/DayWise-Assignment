package ArraysChallenge;

import java.util.Arrays;

public class SortArray {
    public static void main(String[] args) {
        int[] numbers = {10, 4, 8, 1, 6};
        Arrays.sort(numbers);

        System.out.println("Sorted array: " + Arrays.toString(numbers));
    }
}