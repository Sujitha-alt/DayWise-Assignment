package BranchingStatements;

public class ReverseNumber {
    public static void main(String[] args) {
        int number = 1234;
        int reversed = 0;

        do {
            int digit = number % 10;
            reversed = reversed * 10 + digit;
            number = number / 10;
        } while (number != 0);

        System.out.println("Reversed number: " + reversed);
    }
}