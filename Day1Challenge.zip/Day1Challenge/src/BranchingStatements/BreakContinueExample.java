package BranchingStatements;

public class BreakContinueExample {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            if (i == 5) {
                continue; // skips printing 5
            }
            if (i == 9) {
                break; // stops the loop at 9
            }
            System.out.print(i + " ");
        }
    }
}