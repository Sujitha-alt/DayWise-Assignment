package Variables;

public class ConstantExample {
    public static void main(String[] args) {
        final double PI = 3.14159;
        double radius = 5;
        double area = PI * radius * radius;
        System.out.println("Area of circle: " + area);
    }
}