package Variables;

public class VariableShadowing {
    int x = 100;

    public void show() {
        int x = 50;
        System.out.println("Local x: " + x); // shadows instance variable
        System.out.println("Instance x: " + this.x);
    }

    public static void main(String[] args) {
        VariableShadowing obj = new VariableShadowing();
        obj.show();
    }
}