package StringAPI;

public class StringStartEnd {
    public static void main(String[] args) {
        String fileName = "report2025.pdf";

        System.out.println("Starts with 'report': " + fileName.startsWith("report"));
        System.out.println("Ends with '.pdf': " + fileName.endsWith(".pdf"));
    }
}