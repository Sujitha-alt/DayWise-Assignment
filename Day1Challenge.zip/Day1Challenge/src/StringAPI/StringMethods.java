package StringAPI;

public class StringMethods {
    public static void main(String[] args) {
        String word = "JavaProgramming";
        System.out.println("Length: " + word.length());
        System.out.println("Character at index 4: " + word.charAt(4));
        System.out.println("Substring from index 5: " + word.substring(5));
    }
}