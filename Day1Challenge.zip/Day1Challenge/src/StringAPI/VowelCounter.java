package StringAPI;

public class VowelCounter {
    public static void main(String[] args) {
        String s1 = "hello";
        String s2 = "Hello";

        System.out.println("Equals: " + s1.equals(s2));
        System.out.println("Equals Ignore Case: " + s1.equalsIgnoreCase(s2));
    }
}
