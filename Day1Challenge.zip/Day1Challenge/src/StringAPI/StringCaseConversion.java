package StringAPI;

public class StringCaseConversion {
    public static void main(String[] args) {
        String text = "Java Programming";

        System.out.println("Upper case: " + text.toUpperCase());
        System.out.println("Lower case: " + text.toLowerCase());
    }
}
