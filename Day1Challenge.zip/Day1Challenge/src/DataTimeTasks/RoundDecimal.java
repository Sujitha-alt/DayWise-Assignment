package DataTimeTasks;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class RoundDecimal {
    public static void main(String[] args) {
        BigDecimal value = new BigDecimal("123.456789");
        BigDecimal roundedValue = value.setScale(2, RoundingMode.HALF_UP);
        System.out.println("Rounded Value: " + roundedValue);
    }
}
