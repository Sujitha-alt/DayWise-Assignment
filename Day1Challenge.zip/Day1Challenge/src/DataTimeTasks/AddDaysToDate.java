package DataTimeTasks;

import java.time.LocalDate;

public class AddDaysToDate {
    public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        LocalDate futureDate = today.plusDays(5);
        System.out.println("Date after 5 days: " + futureDate);
    }
}
