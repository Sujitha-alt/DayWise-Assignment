package PrimitiveDataTypes;

public class TypeCasting {
    public static void main(String[] args) {
        double d = 10.99;
        int i = (int) d;

        float f = 130.5f;
        byte b = (byte) f;

        System.out.println("Double to int: " + i);
        System.out.println("Float to byte: " + b);
    }
}