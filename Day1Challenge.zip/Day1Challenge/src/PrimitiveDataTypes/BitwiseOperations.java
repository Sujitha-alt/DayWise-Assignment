package PrimitiveDataTypes;

public class BitwiseOperations {
	public static void main(String[] args) {
        int a = 5;
        byte b = 3;

        System.out.println("AND: " + (a & b));
        System.out.println("OR: " + (a | b));
        System.out.println("XOR: " + (a ^ b));
    }
}


