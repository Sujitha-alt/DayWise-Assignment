package PrimitiveDataTypes;

public class ByteOverflow {
    public static void main(String[] args) {
        byte a = 120;
        byte b = 10;
        byte result = (byte)(a + b); 
        System.out.println("Overflow result: " + result);
    }
}