package SwitchChallenges;

import java.util.Scanner;

public class SimpleMenu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("1. Add\n2. Subtract\n3. Multiply\n4. Exit");
        System.out.print("Choose an option: ");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                System.out.println("Addition selected.");
                break;
            case 2:
                System.out.println("Subtraction selected.");
                break;
            case 3:
                System.out.println("Multiplication selected.");
                break;
            case 4:
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Invalid choice.");
        }

        sc.close();
    }
}
