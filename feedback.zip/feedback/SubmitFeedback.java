package com.feedback;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SubmitFeedback")
public class SubmitFeedback extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // 🔍 Check if cookie already exists
        boolean alreadySubmitted = false;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("submitted") && cookie.getValue().equals("true")) {
                    alreadySubmitted = true;
                    break;
                }
            }
        }

        if (alreadySubmitted) {
            // 🚫 User already submitted
            out.println("<html><body>");
            out.println("<h2>You have already submitted your feedback!</h2>");
            out.println("</body></html>");
            return;
        }

        // ✅ First time submission
        String name = request.getParameter("studentName");
        String email = request.getParameter("email");
        String course = request.getParameter("course");
        String feedback = request.getParameter("feedback");

        // Create a new cookie after submission
        Cookie feedbackCookie = new Cookie("submitted", "true");
        feedbackCookie.setMaxAge(60 * 60); // 1 hour validity
        response.addCookie(feedbackCookie);

        out.println("<html><body>");
        out.println("<h2>Thank you for your feedback!</h2>");
        out.println("<p><b>Name:</b> " + name + "</p>");
        out.println("<p><b>Email:</b> " + email + "</p>");
        out.println("<p><b>Course:</b> " + course + "</p>");
        out.println("<p><b>Feedback:</b> " + feedback + "</p>");
        out.println("</body></html>");
    }
}